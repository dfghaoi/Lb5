﻿#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    double x, y;

    cout << "Enter x: ";
    cin >> x;
    cout << "Enter y: ";
    cin >> y;

    if (y <= 1)
    {
        cout << "Condition y > 1 is not satisfied." << endl;
        return 0;
    }

    double a = pow(y, 4);
    double b = pow(y, 3);

    if (x >= a && x <= b)
    {
        cout << "The condition y^4 <= x <= y^3 is satisfied." << endl;

        if (x > 0)
            cout << "x is positive." << endl;
        else if (x < 0)
            cout << "x is negative." << endl;
        else
            cout << "x is equal to zero." << endl;
    }
    else
    {
        cout << "The condition y^4 <= x <= y^3 is NOT satisfied." << endl;
    }

    return 0;
}
